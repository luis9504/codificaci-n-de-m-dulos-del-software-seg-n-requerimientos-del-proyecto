﻿namespace likeshoesapi.DTOs
{
    public class ShoeSectionPostDTO
    {
        public string? SectionName { get; set; }

        public List<int>? ShoeTypeIds { get; set; }
    }
}
