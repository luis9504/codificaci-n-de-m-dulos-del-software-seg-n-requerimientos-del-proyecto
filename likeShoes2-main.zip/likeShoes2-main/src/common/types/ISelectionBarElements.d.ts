import { IShoeSection } from "../types";

export interface ISelectionBarElements {
  nameButton: string;
  sections: IShoeSection[];
}
