export interface IUser {
  email: string;
  full_name: string;
  password: string;
}

export interface IUserRegister {
  email: string;
  password: string;
}
