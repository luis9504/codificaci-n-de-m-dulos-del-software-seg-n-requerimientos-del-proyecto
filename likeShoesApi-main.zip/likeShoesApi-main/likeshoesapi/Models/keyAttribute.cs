﻿
namespace likeshoesapi.Models
{
    internal class keyAttribute : Attribute
    {
    }
}